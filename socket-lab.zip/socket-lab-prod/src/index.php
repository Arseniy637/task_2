<?php

require "header.inc.php";

?>

<div class="container">
    <h3 class="display-3">Pinger</h3>
    <form method="POST" action="" >
        <label for="address">Make your ping request: </label>
        <input id="address" name="address" type="text" placeholder="tty" value="<?php if(isset($_POST["address"])){echo $_POST["address"];}?>">
        <input type="submit" value="show">

        <br>

        <pre align="left">
<?php
        if (isset($_POST["address"]) && !empty($_POST["address"])) {
            $address = trim($_POST["address"]);

            system("ping -c 3 " . $address . " 2>&1");
        } else {
            system("ping -c 1 1.1.1.1 2>&1");
        }
?>
        </pre>

    </form>
    <br>
</div>

<?php
require "footer.inc.php";
?>